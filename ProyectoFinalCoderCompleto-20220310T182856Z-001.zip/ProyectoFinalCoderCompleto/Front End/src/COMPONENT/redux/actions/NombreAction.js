import * as actionTypes from "../consts/actionTypes";

export function getNombre() {
  return {
    type: actionTypes.GET_NOMBRE
  };
}

